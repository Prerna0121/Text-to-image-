import torch
from diffusers import StableDiffusionPipeline
from PIL import Image

# Select Device (Use GPU if available)
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

# Load Stable Diffusion Model (with optimized settings)
model_id = "CompVis/stable-diffusion-v1-4"
print("Loading model... This may take a few minutes.")
pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32)
pipe.to(device)
print("Model loaded successfully!")

def generate_image(prompt, output_path="generated_image.png"):
    """
    Generates an image from text using Stable Diffusion.

    Args:
        prompt (str): The text prompt for the image generation.
        output_path (str): Path to save the generated image.

    Returns:
        Image object: The generated image.
    """
    print(f"Generating image for prompt: {prompt}")
    
    try:
        # Generate image
        image = pipe(prompt).images[0]

        # Save image
        image.save(output_path)
        print(f"Image saved as {output_path}")

        return image

    except torch.cuda.OutOfMemoryError:
        print("CUDA Out of Memory! Try reducing image resolution or using CPU mode.")
        return None

if __name__ == "__main__":
    user_prompt = input("Enter a prompt for image generation: ")
    image = generate_image(user_prompt)

    if image:
        image.show()
    else:
        print("Failed to generate image. Try again with different settings.")
